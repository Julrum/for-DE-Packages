export default {
  currentLanguage: "",
}

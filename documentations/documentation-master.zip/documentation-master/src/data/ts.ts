import en from "./en/ts"
import es from "./es/ts"
import jp from "./jp/ts"
import kr from "./kr/ts"
import pt from "./pt/ts"
import ru from "./ru/ts"
import zh from "./zh/ts"

export { en, es, jp, kr, pt, ru, zh }

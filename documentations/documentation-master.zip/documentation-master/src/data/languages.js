module.exports = {
  langs: ["en", "es", "jp", "zh", "kr", "pt", "ru"],
  defaultLangKey: "en",
}

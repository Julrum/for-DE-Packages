export default {
  primary: "#0e101c",
  secondary: "#bf1650",
  lightBlue: "#516391",
  blue: "#1e2a4a",
  lightPink: "#ec5990",
  errorPink: "#fbecf2",
  buttonBlue: "#191d3a",
  link: "#ff7aa8",
  black: "#000",
}

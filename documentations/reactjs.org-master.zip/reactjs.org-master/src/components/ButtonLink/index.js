/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import ButtonLink from './ButtonLink';

export default ButtonLink;

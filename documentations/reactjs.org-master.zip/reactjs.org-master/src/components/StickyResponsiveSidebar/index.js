/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import StickyResponsiveSidebar from './StickyResponsiveSidebar';

export default StickyResponsiveSidebar;

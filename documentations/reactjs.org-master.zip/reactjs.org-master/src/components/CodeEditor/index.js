/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * @emails react-core
 */

import CodeEditor from './CodeEditor';

export default CodeEditor;

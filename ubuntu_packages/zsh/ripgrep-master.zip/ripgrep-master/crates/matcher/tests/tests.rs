extern crate grep_matcher;
extern crate regex;

mod util;

mod test_matcher;

---
name: Question
about: Ask a question about 'fd'.
title: ''
labels: question
assignees: ''

---



**What version of `fd` are you using?**
[paste the output of `fd --version` here]

#!/bin/bash

test_description='Providing an interactive shell in the proper environment'
. ./test-lib.sh

test_shell
